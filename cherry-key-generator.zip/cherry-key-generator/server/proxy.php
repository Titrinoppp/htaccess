<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

function fetchWithRedirect($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $html = curl_exec($ch);
    
    if(curl_errno($ch)) {
        return ['error' => curl_error($ch)];
    }
    
    // Извлечение ключа (адаптируйте под свою логику)
    preg_match('/window\.location\.href=\'(.+?)\'/', $html, $matches);
    
    if(!isset($matches[1])) {
        return ['error' => 'Redirect URL не найден'];
    }
    
    $redirectUrl = $matches[1];
    
    // Второй запрос для получения ключа
    $ch2 = curl_init($redirectUrl);
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    $keyContent = curl_exec($ch2);
    
    curl_close($ch);
    curl_close($ch2);
    
    // Извлечение последней части ключа
    $key = trim(end(explode('-', $keyContent)));
    
    return [
        'key' => $key,
        'time' => microtime(true)
    ];
}

// Получение URL из параметров
$url = $_GET['url'] ?? '';

if(empty($url)) {
    echo json_encode(['error' => 'URL не указан']);
    exit;
}

$result = fetchWithRedirect($url);
echo json_encode($result);