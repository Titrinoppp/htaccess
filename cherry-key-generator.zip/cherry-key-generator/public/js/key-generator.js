const GAME_URLS = {
    'stand-knife': 'https://cgerrydlc.ru/Cherry/FREEMODS/STANDKNIFE45346546gfffgfgdfgdt456546565646fghgfhghgfhghgfhghghgf1r.php',
    'stand-leo': 'https://cgerrydlc.ru/Cherry/FREEMODS/LEOOOOOOOOOOOOOOOOOOOOOOOOOOOOOoo56465465656546456rtrythghhgfh676765765767657657hjhgjghjghjghjhgjghjghj6786756756fgh1r.php',
    'stand-chillow': 'https://cgerrydlc.ru/Cherry/FREEMODS/CHILLOWSdfdfd6557657676ytythgfhghghgfhty657657657657tythgfhghghgfhg1r.php'
};

const GAME_NAMES = {
    'stand-knife': 'STAND KNIFE',
    'stand-leo': 'STAND LEO', 
    'stand-chillow': 'STAND CHILLOW'
};

document.addEventListener('DOMContentLoaded', () => {
    const gameButtons = document.querySelectorAll('.game-select-btn');
    gameButtons.forEach(button => {
        button.addEventListener('click', () => selectGame(button.dataset.game));
    });
});

async function selectGame(game) {
    const gameSelection = document.getElementById('gameSelection');
    const keyResult = document.getElementById('keyResult');
    const gameTitle = document.getElementById('gameTitle');
    const gameKey = document.getElementById('gameKey');
    const elapsedTime = document.getElementById('elapsedTime');

    gameSelection.classList.add('hidden');
    keyResult.classList.remove('hidden');
    
    gameTitle.textContent = GAME_NAMES[game];
    
    try {
        const proxyUrl = '/server/proxy.php';
        const startTime = performance.now();
        
        const response = await fetch(`${proxyUrl}?url=${encodeURIComponent(GAME_URLS[game])}`);
        const data = await response.json();
        
        const endTime = performance.now();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        const elapsed = ((endTime - startTime) / 1000).toFixed(3);
        elapsedTime.textContent = `${elapsed} сек`;
        
        gameKey.value = data.key || 'Ключ не получен';
    } catch (error) {
        console.error('Ошибка:', error);
        gameKey.value = 'Ошибка получения ключа';
        elapsedTime.textContent = 'Ошибка';
    }
}

function copyKey() {
    const gameKey = document.getElementById('gameKey');
    gameKey.select();
    document.execCommand('copy');
    alert('Ключ скопирован!');
}

function resetGame() {
    const gameSelection = document.getElementById('gameSelection');
    const keyResult = document.getElementById('keyResult');
    
    gameSelection.classList.remove('hidden');
    keyResult.classList.add('hidden');
}